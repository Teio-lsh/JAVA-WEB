import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.ServletContext;

public class RequestLoggingListener implements ServletRequestListener {

    @Override
    public void requestInitialized(ServletRequestEvent sre) {
        HttpServletRequest request = (HttpServletRequest) sre.getServletRequest();
        long startTime = System.currentTimeMillis();
        request.setAttribute("startTime", startTime);
    }

    @Override
    public void requestDestroyed(ServletRequestEvent sre) {
        HttpServletRequest request = (HttpServletRequest) sre.getServletRequest();
        long startTime = (Long) request.getAttribute("startTime");
        long endTime = System.currentTimeMillis();
        long processingTime = endTime - startTime;

        String logMessage = String.format("Time : %s, IP : %s, Method : %s, URI : %s, Query : %s, User-Agent : %s, Processing Time : %d ms",
                new Timestamp(endTime), request.getRemoteAddr(), request.getMethod(),
                request.getRequestURI(), request.getQueryString(), request.getHeader("User-Agent"),
                processingTime);

        ServletContext context = sre.getServletContext();
        context.log(logMessage);
    }
}